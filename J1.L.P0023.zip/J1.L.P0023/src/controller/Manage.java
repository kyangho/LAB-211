/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Fruit;
import entity.Order;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.naming.ldap.HasControls;
import util.Printer;
import util.Validation;

/**
 *
 * @author Duc Ky
 */
public class Manage {
//    ArrayList<ListOrder> listOrder; 
    private ArrayList<Fruit> fruitList;
    private Hashtable<String, ArrayList<Order>> orderTable;
    
    public Manage() {
    }

    public Manage(ArrayList<Fruit> fruitList, Hashtable<String, ArrayList<Order>> orderTable) {
        this.orderTable = orderTable;
        this.fruitList = fruitList;
    }
    
    public void shopping(){
        if (fruitList.isEmpty()){
            System.err.println("Sorry! Our store is out of stock! ");
            return;
        }
        
        //init
        ArrayList<Order> orderList = new ArrayList<>();
        Integer quantity = 0;
        Integer item = 0;
        
        //process
        while(true){
            //display fruit
            System.out.println("List of Fruit: ");
            Printer.displayListFruit(fruitList);
            
            //Input item
            System.out.print("Enter item's number you want to order: ");
            item = Validation.inputIntLimit(1, fruitList.size());
            if (item == null){
                System.err.println("You just skipped order!");
                if (Validation.checkYesNo("Do you want to order now?(Y/N): ")){
                    break;
                }else if(fruitList.isEmpty()){
                    System.err.println("Sorry! Our store is out of stock!");
                    break;
                }
                else{
                    System.err.println("Order new!");
                    continue;
                }
            }
            
            //Enter quantity
            Fruit tmpFruit = fruitList.get(item - 1);
            while(true){
                quantity = Validation.inputInt("Enter quantity: ");
                if (quantity == null) break;
                if (isEnoughFruit(fruitList.get(item - 1).getId(), quantity)){
                    break;
                }
            }
            if (quantity == null){
                System.err.println("You just skipped order!");
                if (Validation.checkYesNo("Do you want to order now?(Y/N): ")){
                    break;
                }else if(fruitList.isEmpty()){
                    System.err.println("Sorry! Our store is out of stock!");
                    break;
                }
                else{
                    System.err.println("Order new!");
                    continue;
                }
            }
            orderList = updateOrder(new Order(tmpFruit.getId(), tmpFruit.getName(), quantity, tmpFruit.getPrice()), orderList);
            
            //Ask to continue order
            if (Validation.checkYesNo("Do you want to order now?(Y/N): ")){
                break;
            }else if(fruitList.isEmpty()){
                System.err.println("Sorry! Our store is out of stock!");
                break;
            }
            else{
                System.err.println("Order new!");
            }
        }
        if (orderList.isEmpty()){
            System.out.println("You didn't order anything");
            return;
        }
        //Display order
        Printer.viewOrder(orderList);
        
        //Enter customer's name
        Pattern pattern = Pattern.compile("[a-zA-z\\s]+");
        Matcher matcher;
        String name;
        while(true){
            name = Validation.inputString("Enter your name: ", false);
            matcher = pattern.matcher(name);
            if(!matcher.matches()){
                System.err.println("Invalid name, enter again!");
                continue;
            }
            name = Validation.beautyName(name);
            break;
        }
        orderTable.put(name, orderList);
    }
    
    private boolean isEnoughFruit(String fruitId, int amount){
        Fruit tmp;
        int i = 0;
        for (Iterator<Fruit> fruit = fruitList.iterator(); fruit.hasNext();){
            Fruit f = fruit.next();
            if (fruitId.compareTo(f.getId()) == 0){
                if (amount <= f.getQuantity()){
                    tmp = new Fruit(f.getId(), f.getName(), f.getPrice(), f.getQuantity() - amount, f.getOrigin());
//                    f.setQuantity(f.getQuantity() - amount);
                    fruitList.set(i, tmp);
                    if (fruitList.get(i).getQuantity() == 0){
                        fruit.remove();
                    }
                    return true;
                }else{
                    System.err.println("Remaining " + f.getName() + " fruit in store: " + f.getQuantity());
                    System.err.println("There is not enough fruit to order. Enter again!");
                    return false;
                }

            }
            i++;
        }
        return false;
    }
    public ArrayList<Order> updateOrder(Order order, ArrayList<Order> orderList){
        if (order.getQuantity() == 0) return orderList;
        Order oTmp;
        int i = 0;
        for (Order o : orderList){
            if(o.getFruitId().compareTo(order.getFruitId()) == 0){
//                o.setQuantity(order.getQuantity() + o.getQuantity());
                oTmp = new Order(o.getFruitId(), o.getFruitName(), o.getQuantity() + order.getQuantity(), o.getPrice());
                orderList.set(i, oTmp);
                return orderList;
            }
            i++;
        }
        orderList.add(new Order(order.getFruitId(), order.getFruitName(), order.getQuantity(), order.getPrice()));
        return orderList;
    }

    
}
